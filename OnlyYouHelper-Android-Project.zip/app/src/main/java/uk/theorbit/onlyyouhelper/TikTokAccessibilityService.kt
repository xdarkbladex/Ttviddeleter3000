package uk.theorbit.onlyyouhelper

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TikTokAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("helper", MODE_PRIVATE) }
    private var lastClickAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !prefs.getBoolean("armed", false)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != "com.zhiliaoapp.musically" && pkg != "com.ss.android.ugc.trill") return

        // Only act on the exact audience label. Never click destructive controls or save buttons.
        val now = System.currentTimeMillis()
        if (now - lastClickAt < 1200) return
        val root = rootInActiveWindow ?: return
        val target = findExactOnlyYou(root) ?: return
        val clicked = clickSelfOrClickableParent(target)
        if (clicked) {
            lastClickAt = now
            val count = prefs.getInt("count", 0) + 1
            prefs.edit()
                .putInt("count", count)
                .putString("last_action", "Selected “Only you” at ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.UK).format(java.util.Date())}")
                .apply()
        }
    }

    private fun findExactOnlyYou(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (text.equals("Only you", ignoreCase = true) || desc.equals("Only you", ignoreCase = true) ||
            text.equals("Only me", ignoreCase = true) || desc.equals("Only me", ignoreCase = true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findExactOnlyYou(child)
            if (found != null) return found
        }
        return null
    }

    private fun clickSelfOrClickableParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.isEnabled) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < 4) {
            if (parent.isClickable && parent.isEnabled) {
                val ok = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                parent.recycle()
                return ok
            }
            val next = parent.parent
            parent.recycle()
            parent = next
            depth++
        }
        parent?.recycle()
        return false
    }

    override fun onInterrupt() {}
}
