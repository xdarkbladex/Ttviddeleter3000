package uk.theorbit.onlyyouhelper

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("helper", Context.MODE_PRIVATE) }
    private lateinit var armedStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::armedStatus.isInitialized) updateStatus()
    }

    private fun render() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF101116.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, pad)
        }

        content.addView(TextView(this).apply {
            text = "ONLY YOU HELPER"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "A small, local assistant for changing TikTok post audiences."
            textSize = 15f
            setTextColor(0xFFB8BAC5.toInt())
            setPadding(0, 8, 0, 20)
        })

        content.addView(card(
            "What this app can do",
            "• While TikTok is open, look for the exact “Only you” option on its audience menu and select it when helper mode is armed.\n• Keep a local count of selections.\n• Open TikTok and Android Accessibility settings."
        ))
        content.addView(card(
            "What it cannot do",
            "• It cannot bulk-select all your posts or guarantee that TikTok exposes the same controls on every account.\n• It does not press Save/Post, delete videos, change account privacy, or collect your TikTok password.\n• You must open each post's audience setting yourself and confirm/save it yourself."
        ))
        content.addView(card(
            "Safety",
            "Accessibility access is powerful. Enable it only if you trust this app. This project has no network permission and stores its armed state and selection count on this device. It only acts inside TikTok when it sees the exact “Only you” label."
        ))

        armedStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 14)
        }
        content.addView(armedStatus)

        content.addView(button("1. Enable Android accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(button(if (prefs.getBoolean("armed", false)) "Pause helper" else "Arm helper") {
            val newState = !prefs.getBoolean("armed", false)
            prefs.edit().putBoolean("armed", newState).apply()
            Toast.makeText(this, if (newState) "Helper armed" else "Helper paused", Toast.LENGTH_SHORT).show()
            updateStatus()
            renderButtonState()
        }.also { it.tag = "arm" })
        content.addView(button("2. Open TikTok") { openTikTok() })
        content.addView(button("Reset local selection count") {
            prefs.edit().putInt("count", 0).apply()
            updateStatus()
        })
        content.addView(TextView(this).apply {
            text = "Suggested workflow\n1. Enable the service above.\n2. Arm the helper.\n3. Open TikTok and open one of your own posts' audience/privacy controls.\n4. When “Only you” appears, the helper may select it.\n5. Review the setting and tap TikTok's own Save/Done button yourself. Repeat for each post.\n6. Pause the helper when finished."
            textSize = 14f
            setTextColor(0xFFB8BAC5.toInt())
            setPadding(0, 20, 0, 0)
        })

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
        updateStatus()
    }

    private fun card(title: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0xFF20222B.toInt())
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(0xFFD8D9E0.toInt())
            setPadding(0, 8, 0, 0)
        })
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
        box.layoutParams = params
        return box
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
        }

    private fun renderButtonState() {
        // Recreate screen so the arm/pause label matches the stored state.
        render()
    }

    private fun updateStatus() {
        if (!::armedStatus.isInitialized) return
        val armed = prefs.getBoolean("armed", false)
        val count = prefs.getInt("count", 0)
        val last = prefs.getString("last_action", "No selections yet")
        armedStatus.text = "Helper: ${if (armed) "ARMED" else "PAUSED"}\nExact “Only you” selections this session: $count\nLast action: $last"
    }

    private fun openTikTok() {
        val packages = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                return
            }
        }
        startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/")))
    }
}
